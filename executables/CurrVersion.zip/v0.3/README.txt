:::::::::::::::::::::::::::::::::
::                             ::
::       SimpleGlossary        ::
::       ~By Evan Wang~        ::
::                             ::
:::::::::::::::::::::::::::::::::
Current Version 0.2

Thank you for downloading SimpleGlossary!
Using the program:
	~To run the program, double click the file SimpleGlossary.jar inside of this directory.
	~The program will automatically load up and display a blank screen to you.
	~When adding or removing a term, there is a button allowing you to insert special characters. This button opens a separate dialog and allows you to select a special character. It also has an option to make a character a 'favorite'. When you favorite a character, it is automatically saved to your settings in the file sconfig~, also in this directory. To reset your favorites to default, you can delete this file. 
	~Files can be exported as text files if you want a static copy that's easier to read, or if you want to put the data in some other document. 
	~If you encounter an error, please run the file DEBUG.bat and try to reproduce your error, then check to see if the program outputs anything in the console.

Important note:
The files in the sys folder are used by the program for various configurations. Do not modify them.
However, if you wish to reset your special character favorites list, delete the file sconfig~


